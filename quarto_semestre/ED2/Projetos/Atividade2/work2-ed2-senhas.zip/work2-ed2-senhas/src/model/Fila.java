package model;

public class Fila {

	public Fila() {
		//
	}

}
