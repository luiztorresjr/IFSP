package model;

public class Item {

	public Item() {
		// 
	}

}
