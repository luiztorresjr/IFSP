package controller;

public class MainController {
	
	public MainController (){
		
	}
	
	public void retirarSenhaNormal (){
		System.out.println("Clicou no botão Normal");
	}
	
	public void retirarSenhaPreferencial(){
		System.out.println("Clicou no botão Preferencial");
	}
	
	public void chamarSenha (){
		System.out.println("Clicou no botão Chamar Senha");
	}
	
	public void atualizarSenhaAtual(){
		//
	}

}
