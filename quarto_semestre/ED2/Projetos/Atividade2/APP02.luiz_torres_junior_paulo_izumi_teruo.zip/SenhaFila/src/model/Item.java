package model;
//cria a classe item que tera um dado e o ponteiro
public class Item {
	public String senha;
	public Item proximo;
	public Item() {
		
	}
	
}
