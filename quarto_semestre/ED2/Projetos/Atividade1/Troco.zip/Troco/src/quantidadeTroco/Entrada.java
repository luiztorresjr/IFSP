/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quantidadeTroco;

/**
 *
 * @author Megaware
 */

import java.util.InputMismatchException;
import java.util.Locale;
import java.util.Scanner;

public class Entrada {
    private static Scanner s;

	public static void main(String[] args) {
			float troco;
			boolean verifica = true;
			System.out.printf("Oi. Quanto troco você deve?\n");
			do{
				try{				
					s = new Scanner(System.in);				
					s.useLocale(Locale.ENGLISH);
					String valor =s.next();					
                                        if(valor.contains(",")){
                                            throw new Excecao("Desculpe? Quanto você disse?");
                                        }
                                        else {
                                                troco = Float.parseFloat(valor);
                                                if(troco < 0f){
						 throw new Excecao("Desculpe? Quanto você disse?");
                                                }
						Calcula c = new Calcula();
						c.calcula(troco*100);
						verifica = false;
					}
				}				
				catch(NumberFormatException e){
					System.out.printf("Ahh... Tente de novo\n");					
				}
				catch(Exception a){
					System.out.printf("Desculpe? Quanto você disse?");
				}
			
			}while(verifica);
	}
}
