/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quantidadeTroco;

/**
 *
 * @author Megaware
 */
public class Calcula {	
	private int moeda;

	public void calcula(float troco){
		moeda = 0;
		int valor;
		valor = (int) troco;	
		do{
			if(valor>=25){
				valor=valor-25;
				moeda++;				
			}
			else if(valor<25 && valor >= 10){
				valor=valor-10;
				moeda++;				
			}
			else if(valor < 10 && valor>=5){
				valor=valor-5;
				moeda++;				
			}
			else{
				valor=valor-1;
				moeda++;				
			}
		}while(valor>0);			
		System.out.printf(""+moeda);
	}

}
