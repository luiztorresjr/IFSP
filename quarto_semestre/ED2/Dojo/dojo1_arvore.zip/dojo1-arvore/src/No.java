public class No {

	public int valor;
	public No direito;
	public No esquerdo;

	// metodo construtor
	public No(int p_valor) {
		valor = p_valor;
		direito = null;
		esquerdo = null;

	}

}
