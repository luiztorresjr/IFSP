
public class MainLista {

	public MainLista() {
		
	}

	public static void main(String[] args) {
		
		
		Lista lista = new Lista();
		lista.adicionarItemComeco(25);
		lista.adicionarItemComeco(37);
		lista.adicionarItemFim(40);
		lista.imprimirLista();

	}

}
