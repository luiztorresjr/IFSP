
public class Item {

	public int valor;
	
	public Item proximo;
	
	public Item() {
	}

}
